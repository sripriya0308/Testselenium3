package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class FirstScript {
	
	@Given("^Start the script$")
	public void start() {
		System.out.println("script execution started");
			
	}
	
	@Then("^script execution in progress$")
	public void execution_in_progress() {
		
		System.out.println("execution in progress");
		
	}
	
	@And("^Execution completed$")
	public void executioncompleted() {
		
		System.out.println("execution completed");
	}
	
	

}
